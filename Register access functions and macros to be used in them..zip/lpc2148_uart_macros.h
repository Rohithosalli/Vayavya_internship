#pragma once

#include <stdio.h>
#include <string.h>
#include "lpc2148_uart_reg_axs.h"

#define MEG(x) (x * 1000 * 1000)

/* enum { e_five, e_six, e_seven, e_eight };
enum { e_odd, e_even, e_no };
enum { e_stp_bit_1, e_stp_bit_2 }; */

// word length macro
#define e_five  0
#define e_six   1
#define e_seven 2
#define e_eight 3

// parity macros
#define e_odd   0
#define e_even  1
#define e_no    2

// stop bit macros
#define e_stp_bit_1    0
#define e_stp_bit_15_2 1

// Register offsets
#define U0RBR_OFF         0x00
#define U0THR_OFF         0x00
#define U0IER_OFF         0x04
#define U0IIR_OFF         0x0C
#define U0FCR_OFF         0x08
#define U0LCR_OFF         0x0C
#define U0LSR_OFF         0x14
#define U0SCR_OFF         0x1C
#define U0FDR_OFF         0x28
#define U0DLL_OFF         0x00
#define U0DLM_OFF         0x04

/* LCR high and low bit positions */
#define U0LCR_WLS_HPOS       0x1
#define U0LCR_WLS_LPOS       0x0

#define U0LCR_STPBIT_HPOS    0x2
#define U0LCR_STPBIT_LPOS    0x2

#define U0LCR_PEN_HPOS       0x3
#define U0LCR_PEN_LPOS       0x3

#define U0LCR_PARSEL_HPOS    0x5
#define U0LCR_PARSEL_LPOS    0x4

#define U0LCR_BRKCTL_HPOS    0x6
#define U0LCR_BRKCTL_LPOS    0x6

#define U0LCR_DLAB_HPOS      0x7
#define U0LCR_DLAB_LPOS      0x7

/* LSR high and low bit positions */
#define U0LSR_DR_HPOS        0x0
#define U0LSR_DR_LPOS        0x0

#define U0LSR_OE_HPOS        0x1
#define U0LSR_OE_LPOS        0x1

#define U0LSR_PE_HPOS        0x2
#define U0LSR_PE_LPOS        0x2

#define U0LSR_FE_HPOS        0x3
#define U0LSR_FE_LPOS        0x3

#define U0LSR_BI_HPOS        0x4
#define U0LSR_BI_LPOS        0x4

#define U0LSR_THRE_HPOS      0x5
#define U0LSR_THRE_LPOS      0x5

// UART Rx error identification macros
#define OE_ERR(x) ((x >> U0LSR_OE_LPOS) & 1)
#define PE_ERR(x) ((x >> U0LSR_PE_LPOS) & 1)
#define FE_ERR(x) ((x >> U0LSR_FE_LPOS) & 1)
#define BI_ERR(x) ((x >> U0LSR_BI_LPOS) & 1)

// UART Rx error return values to be used in the application
#define RX_OE  1
#define RX_PE  2
#define RX_FE  3
#define RX_BI  4
