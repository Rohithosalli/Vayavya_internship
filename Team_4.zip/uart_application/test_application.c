#include<LPC21xx.h>
#include<stdio.h>
#include "Team_4_uart.h"
int main()

{
unsigned char msg[]={"BVB"}; // data to be sent
unsigned char * data ;
unsigned int rec_data=0;
int i;
PINSEL0 = 0x00000005;

configure_baudrate (9600, 1.8432); 


configure_data_width (e_eight); // 8 bit character 

configure_stop_bit (e_stp_bit_2); // 0x04 value or 1.0

configure_parity (e_odd); // enable parity and set it to even parity (using enum)

while(rec_data==0)
{
for ( i=0;i<3;i++) {

transmit_data (msg[i]);

rec_data = receive_data (data);

if(rec_data == 0){
printf("Error in receiving data");
break;
}
}
}

}

