#include "../include/lpc2148_uart_macros.h"
#include "../include/lpc2148_uart_reg_axs.h"

/***************************************************************************
 * 1) When required to read from the entire register use the function: reg_rd 
 * 2) When required to write into the entire register use the function: reg_rd 
 * 3) When required to read from specific bits of register use the function: 
 * reg_fld_rd 
 * 4) When required to write into specific bits of register use the function: 
 * reg_fld_wr 
 ***************************************************************************
 * All the above mentioned functions are present in the file:
 * lpc2148_reg_axs_funs.c
 **************************************************************************/

void configure_baudrate (unsigned int baud, unsigned int clk){
 /* The divisor value as per the datasheet (page 151) is:
   * baud_rate = (PCLK/16 * 16bit-divisor-value) * (MulVal/(MulVal + DivAddVal);
   * By default MulVal = 1 and DivAddVal = 0, so the formula becomes
   * baud_rate = (PCLK/16 * 16bit-divisor-value) 
   * To calculate the divisor value it is:
   * 16bit-divisor-value = PCLK/baud_rate
   *
   * write 1 into dlab bit of LCR
   * program DLL and DLM with the 16 bit divisor value
   * write 0 into dlab bit of LCR 
   *
  */
}

static void configure_data_width (unsigned char wl)
{
  /* program LCR register's bit 0 and 1 based on the value of the
   * argument: wl
   */
}

static void configure_stop_bit (unsigned char stop_bit)
{
  /* program LCR register's bit 2 based on the value of the
   * argument: stop_bit
   */
}

static void configure_parity (unsigned char par)
{
  /* program LCR register's bit 3 & 4 based on the value of the
   * argument: par
   */
}

void configure_data_packet (unsigned char dlen, unsigned char stp_bit,
    unsigned char par)
{
  /* Call the functions to configure the data length, stop bit and parity
   * by passing the corresponding arguments received by this function as
   * shown below.
   */
  configure_data_width (dlen);
  configure_stop_bit (stp_bit);
  configure_parity (par);
}


int transmit_data (unsigned char data)
{
    /* check if THR is empty
       THR = data;
    */
 }

int receive_data (unsigned char *data)
{
  int err = 0;

  /* check for data valaible and errors in the LSR Register.
   * if there are errors initalize err to non-zero value
   * write the contents of RBR into data.
   */
   
  return err;
}
