#include "lpc2148_uart_macros.h"
#include "lpc2148_uart_reg_axs.h"



static volatile unsigned char *base_addr = ((volatile unsigned char *) 0xE000C000);

/**
 * brief Writes "val" into the register at offset off
 * @param off   : offset of the 8 bit register into which value has to be written
 * valid values : Any valid offset (defined in lpc2148_macros.h)
 * @param val   : The value to be written into the register
 * return none
 */
void reg_wr (int off, unsigned char val)
{
  volatile unsigned char *ba = base_addr + off;

  *ba = val;
}

/**
 * brief Reads value in the register at offset off
 * @param off   : offset of the 8 bit register from which value has to be read
 * valid values : Any valid offset (defined in lpc2148_macros.h)
 * return value read from register
 */
unsigned char reg_rd (int off)
{
  volatile unsigned char *ba = base_addr + off;
  unsigned char val;

  val = *ba;
  return val;
}

/**
 * @brief Writes the "val" into the bit positions "hpos" - "lpos" in the 
 *        register at offset "off".
 *       
 * @param off   : offset of the 8 bit register whose field value has to be written
 * valid values : Any valid offset (defined in lpc2148_macros.h)
 * @param hpos  : The high bit position to where the value is to be written
 * valid values : 0 - 7
 * @param lpos  : The low bit position upto where the value is to be written 
 * valid values : 0 - 7
 * @param val   : The value to be written from hpos - lpos
 * valid values : any value that can be specified in a (hpos - lpos + 1) 
 *                number of bits.
 *
 * @return none
 */

void reg_fld_wr (int off, unsigned int hpos,
                 unsigned int lpos, unsigned char val)
{
  unsigned rval;
  unsigned int width = hpos - lpos + 1;

  // first get current value
  rval = reg_rd(off);
  // set the bits we want to write to 0
  /*
   */
  rval = rval & ~((~(~0 << width)) << lpos);
  // write new value val by shifting it to correct position an ORing
  rval = rval | (val << lpos);
  // write the new register contents ino the register
  reg_wr(off, rval);
}

/* Register field write
 * Assume hpos is 4 and lpos 3. So width = hpos - lpos + 1 = 2
 * void reg_fld_wr (int off, int hpos, int lpos, unsigned char val)
 * {
 *   unsigned char uc;
 *   unsigned char mask;
 *
 *   uc = reg_rd (off);
 *   mask = (unsigned char)~0;  // mask -> 11111111
 *   mask = mask << width;      // mask -> 11111100
 *   mask = ~mask;              // mask -> 00000011
 *   mask = mask << lpos;       // mask -> 00001100
 *   mask = ~mask;              // mask -> 11110011
 *   uc = uc & mask;            // bits 3 and 4 become 0
 *   uc = uc | (val << lpos);   // bits 3 and 4 set to new value
 *   reg_wr (off, uc);
 * }
 */

/**
 * @brief Returns the value present in "reg" from the "hpos" bit position
 *        to the "lpos" bit position.
 *       
 * @param off   : Offset of the register whose bit field has to be read
 * valid values : Any valid offset (defined in lpc2148_macros.h)
 * @param hpos  : The high bit position from where the value is to be read
 * valid values : 0 - 7
 * @param lpos  : The low bit position upto where the value is to be read 
 * valid values : 0 - 7
 *
 * @return value value of the bit field read from the register.
 */

unsigned char reg_fld_rd(int off, unsigned int hpos, unsigned int lpos)
{
  unsigned char rval;
  unsigned int width = hpos - lpos + 1;

  // read register contents
  rval = reg_rd(off);
  // extract desired bits
  rval = rval & ((~(~0 << width)) << lpos);
  // shift the bits to 0th bit position
  rval = rval >> lpos;

  return rval;
}

/* Register field read
 * Assume hpos is 6 and lpos 4. So width = 3
 * unsigned char reg_fld_rd (int off, int hpos, int lpos)
 * {
 *   unsigned char uc;
 *   unsigned mask;
 *
 *   uc = reg_rd (off);
 *   mask = (unsigned char)~0;   // mask -> 11111111
 *   mask = mask << width;       // mask -> 11111000
 *   mask = ~mask;               // mask -> 00000111
 *   mask = mask << lpos;        // mask -> 01110000
 *   uc = uc & mask;             // bits 6-4 unchanged and all other bits 0
 *   uc = uc >> lpos;            // bit 4 in 0th position now
 *   return uc;
 * }
 */
