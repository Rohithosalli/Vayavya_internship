/**
 * @brief Configures the baud rate of the UART
 *
 * @param baud : the baud rate of the UART
 *               data to be transmitted
 * valid values: 50 ...128000
 * @param clock: the input clock frequency in
 *               MHz.
 * valid values: 1.8432MHz, 
 *               3.072MHz,
 *               18.432MHz
 *
 * @return none
 */
void configure_baudrate (unsigned int baud,    
                         float clock);

/**
 * @brief Configures the data transmission 
 *.       of the UART
 * @param word_len : the word length of the  
 *.                 UART data to be sent
 * valid values   : 5, 6, 7, 8
 * @return none
 */
void configure_data_width( unsigned char word_len);

/**
 * @brief Configures the stop bit of the data
 *        transmission.
 * @param stop_bit : Number of stop bits.
 * valid value : 1 for 1 stop bit
 *               2 sets 1.5 stop bit when data 
 *                 length is 5.
 *               2 sets 2 stop bit when data 
 *                 length is 6, 7, 8. 
 * @return none
 */
void configure_stop_bit (
                    unsigned char stop_bit);

/**
 * @brief Configures the parity bit of the data.
 * @param parity   : the parity setting
 * valid values    : 0 = even parity,
 *                   1 = odd parity,
 *                   2 = no parity
 * @return none
 */
void configure_parity (unsigned char par);

/**
 * @brief Configures the data transmission of
 *        the UART
 * @param data_len : the word length of the
                     uart data to be sent
 * valid values   : 5, 6, 7, 8
 * @param stop_bit : Number of stop bit of the
                     data.
 * valid values    : 1, 2
 * @param parity   : the parity setting
 * valid values    : 0 = even parity, 
                     1 = odd parity, 
                     2 = no parity
 * @return none
 */
void configure_data_packet( unsigned char data_len3, 
                            unsigned char stop_bit, 
                            unsigned char parity);

/**
 * @brief transmit data of the UART
 * @param data : one byte of data to be transmitted        
 * @return : none
 */
void transmit_data (unsigned char data);


/**
 * @brief receive data of the UART
 * @param data : one byte of data to be received
 * @return : 0 for success
 *           1 for failure
 */
int receive_data (unsigned char *data);


