
/**
 * @brief Configures the baud rate of the UART
 *
 * @param baud : the baud rate of the UART data to be transmitted
 * valid values: 50 ...128000
 * @param clock: the input clock frequency in MHz is from the crystal clock. 
 * valid values: 1.8432MHz, 3.072MHz, 18.432MHz
 *
 * @return none
 */
void configure_baudrate (unsigned int baud, float clock);


/**
 * @brief specify the number of bits in each transmitted or received serial character.
 *
 * @param data_length :the two bits (Bit 0 and Bit 1) specify the length of transmitted or received serial character.

 * valid values: 5 bits, 6 bits, 7 bits, 8 bits
 *
 * @return none
 */

void configure_data_width (unsigned int data_length );


/**
 * @brief  This bit specifies the number of Stop bits transmitted
and received in each serial character.
 *
 * @param stop : generates a stop bit based on the logic state and length of character
 * valid values:1, 1.5, 2, by using emun assigning value(1,2,2)
 *
 * @return None
 */

void configure_stop_bit (unsigned char stop);


/**
 * @brief This will enable the parity bit and set the even odd parity.
 *
 * @param enable : Set the parity bit.
 * valid values: 0-even parity, 1-odd parity, 2-no parity
 *
 * @return None
 */
void configure_parity (unsigned char enable);


/**
 * @brief specifies the data length, the stop bit and parity bit.
 *
 * @param data_length : specify the length of transmitted or received serial character
 * valid values: 5 bits, 6 bits, 7 bits, 8 bits
 *
 * @param stop : generates a stop bit based on the logic state and length of character
 * valid values: 1, 1.5, 2 by using emun assigning value(1,2,2)
 *
 * @param set_e_o : This will select either even or odd parity.
 * valid values: 0-even parity, 1-odd parity, 2-no parity
 *
 * @return none
 */
void configure_data_packet (unsigned char data_length, unsigned char stop, unsigned char set_e_o );


/**
 * @brief start the transmitting process.
 *
 * @param data : data that needs to be transmited.
 * valid values: depends on user the what he wants character or numbers.
 *
 * @return : none
 */
 void transmit_data (unsigned char data);


/**
 * @brief start the reading process.
 *
 * @param data: data that read from RBR resistor.
 *
 * @return : 0 gives no error while receving data.
 *           1 error in received data.
 */
 int receive_data (unsigned char *data);







