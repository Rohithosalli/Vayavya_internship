#include<LPC21xx.h>
#include<stdio.h>

int main()
{
  unsigned char msg[]={"Hello"};		
  unsigned char data[];
  PINSEL0 = 0x00000005;
  configure_data_width(8);

  configure_baudrate(19200,1.8432); //UB: Verify if this results in the DLL 0x61.
                                    // Refer sections 11.3.4 and 11.3.5 in the 
                                    // datasheet for LPC2148


  configure_stop_bit(1); 

  configure_parity(0);

  int count=0;
  int flag=0;
  while(count<4){  // Transmitting and receiving the data 4 times 
    for(int i=0;i<5;i++){
        transmit_data(msg[i]); // transmitting one character at a time
        int err = receive_data(&data); //UB: As per your header file the error
                                       //is an argument and data is the return
                                       //value. But here it is done differently
        if(err==0){
          printf("No error\n");
        }
        else{
          printf("Error has occured\n");
          flag=1;
          break;
        } 
    }
    if(flag==0){
      printf("Received data is : %s",data); 
    }
    else{
      printf("There is an error in the received data");
    }
    flag=0;
    count++;   
  }
}
