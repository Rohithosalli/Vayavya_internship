/*

decToBinary is a function used to convert decimal to binary.
First, we clear a bit of the data (x).

clear bit:
 1. Perform a left-shift operation
 2. perform NOT operation
 3. Perform AND operation  

Set bit :
 1. Perform a left-shift operation
 2. perform OR operation


*/

#include <stdio.h> 
// Function to convert decimal to binary
void decToBinary(int n) {
    int binaryNum[1000];
    int i = 0;

    while (n > 0) {
        binaryNum[i] = n % 2;
        n = n / 2;
        i++;
    }

    for (int j = i - 1; j >= 0; j--)
        printf("%d ", binaryNum[j]);
}
int bit_manu(unsigned int val, int bit_position){
unsigned int x = val;
x &= ~(1<< bit_position);
x |= (1<<bit_position);
return x;
}
int main() 
{ 
/*
 // clear bit
 	printf("\n clear a bit \n \n ");
	unsigned int x = 138; 
	unsigned int y =  (1<<0); //  left shift 1 to bit position 5 
	unsigned int q = ~y;   // making bit position 5 to 0 by NOT 
     unsigned int z = x & q; //  applying mask by using AND
    printf(" intput x --> %d \n",x);
	//decToBinary(x);
	printf("\n\n");
    printf("output z --> %x\n",z);
	//decToBinary(z);


	printf("\n \n set a bit \n \n ");


// set bit

	int a = z; 
    int b = 1<<5; //  left shift 1 to bit position 5 
	int c = z | b; // applying mask by using OR
    printf("\n input a --> %d\n",a);
	decToBinary(z);
    printf(" \n output c --> %d\n",c);
	decToBinary(c);
*/

int val, bit,res;
printf("enter a no: \n");
scanf("%d",val);
decToBinary(val);
printf("enter bit position you want to change:");
scanf("%d",bit);
res = bit_manu(val,bit);
decToBinary(res);
	return 0; 
}
