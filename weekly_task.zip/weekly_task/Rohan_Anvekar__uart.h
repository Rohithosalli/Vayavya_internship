/*
 * This is the header file containing the driver function declarations for
 * LPC2148's UART written by <name of the student>
 */


/**
 * @brief Configures the baud rate of the UART
 *
 * @param baud : the baud rate of the UART data to be transmitted
 * valid values: 50 ...128000
 * @param clock: the input clock frequency in MHz is from the crystal clock. 
 * valid values: 1.8432MHz, 3.072MHz, 18.432MHz
 *
 * @return none
 */
void configure_baudrate (unsigned int baud, float clock);




/**
 * @brief specify the number of bits in each transmitted or received serial character.
 *
 * @param data_length :the two bits (Bit 0 and Bit 1) specify the length of transmitted or received serial character.

 * valid values: 5 bits, 6 bits, 7 bits, 8 bits
 *
 * @return none
 */

void configure_data_width (unsigned int data_length );







/**
 * @brief  This bit specifies the number of Stop bits transmitted
and received in each serial character.
 *
 * @param stop : generates a stop bit based on the logic state and length of character
 * valid values:1, 1.5, 2
 *
 * @return None
 */

void configure_stop_bit (int stop);









/**
 * @brief This will enable the parity bit and set the even odd parity.
 *
 * @param enable : when this is logic 1 parity bit is generated.
 * valid values: Logic 1 or Logic 0
 *
 * @param set_e_o : This will select either even or odd parity.
 * valid values:  1 for odd, 0 for even
 *
 * @return None
 */
void configure_parity (unsigned int enable, unsigned int set_e_o);





/**
 * @brief specifies the data length, the stop bit and parity bit.
 *
 * @param data_length : specify the length of transmitted or received serial character
 * valid values: 5 bits, 6 bits, 7 bits, 8 bits
 *
 * @param stop : generates a stop bit based on the logic state and length of character
 * valid values: 1, 1.5, 2
 *
 * @param set_e_o : This will select either even or odd parity.
 * valid values: 1 for odd, 0 for even
 *
 * @return none
 */
void configure_data_packet (unsigned int data_length, unsigned int stop, unsigned int set_e_o );






/**
 * @brief start the transmitting process.
 *
 * @param data : transmits data by setting value of DLAB of LCR resistor to 0.
 * valid values: depends on user the what he wants to transmit bit (5 to 8).
 *
 * @return int [1-> transmission sucessfull
 *             0-> transmission failed (due to data present in THR resistor)]
 */
unsigned int transmit_data (unsigned char data);





/**
 * @brief start the reading process.
 *
 * @param : 
 * valid : 
 *
 * @return hexa-decimal value, First check the status register, and then the RBR register. Based on this it returns the hexa-decimal value,specific bit for data received correctly and specific bit if data is currepted.
 */
unsigned int receive_data ();







